from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk 


class info:
    def __init__(self,root):
        self.root=root
        self.root.title("Naval Point Hotel Management")
        self.root.geometry("1295x550+230+220")
        
        #======================Title========
        
        lbl_title=Label(self.root,text="INFORMATION  OWNER & MANAGER",font=("times new roman",18,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1295,height=50)
        
        
        #======================image=======
        
        
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,text="OWNER",font=("times new roman",12,"bold"),padx=2,)
        labelframeleft.place(x=10,y=50,width=540,height=490)


        img2=Image.open("Images/owner 999.jpg")
        img2=img2.resize((150,150),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)
         
        lbing=Label(self.root,image=self.photoimg2,bd=0,relief=RIDGE)
        lbing.place(x=190,y=80,width=150,height=150)
        
        #=============details=====
        lblown_n=Label(labelframeleft,text="Owner Name:  Ejabur Rahman",font=("times new roman",15,"bold"),padx=2,pady=6)
        lblown_n.place(x=10,y=160)
        
        lblown_p=Label(labelframeleft,text="Owner Phone Num:  01818182729",font=("times new roman",15,"bold"),padx=2,pady=6)
        lblown_p.place(x=10,y=190)
        
        lblown_e=Label(labelframeleft,text="Owner Email:  Ejabur.Rahman12@gmail.com",font=("times new roman",15,"bold"),padx=2,pady=6)
        lblown_e.place(x=10,y=220)
        
        
       
        
        
        
     #===================manager========   
        
        labelframeleft=LabelFrame(self.root,bd=2,relief=RIDGE,text="MANAGER",font=("times new roman",12,"bold"),padx=2,pady=6)
        labelframeleft.place(x=600,y=50,width=540,height=490)
        
        img3=Image.open("Images/236555083.jpg")
        img3=img3.resize((150,150),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)
         
        lbing=Label(self.root,image=self.photoimg3,bd=0,relief=RIDGE)
        lbing.place(x=800,y=80,width=150,height=150)
        
        #===========details======
        
        lblman_n=Label(labelframeleft,text="Manager Name:  Shamima Akter",font=("times new roman",15,"bold"),padx=2,pady=6)
        lblman_n.place(x=10,y=160)
        
        lblman_p=Label(labelframeleft,text="Manager Phone Num:  01977213130",font=("times new roman",15,"bold"),padx=2,pady=6)
        lblman_p.place(x=10,y=190)
        
        lblman_e=Label(labelframeleft,text="Manager Email:  Shamima1202@gmail.com",font=("times new roman",15,"bold"),padx=2,pady=6)
        lblman_e.place(x=10,y=220)
        
        
        
        


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
if __name__ == '__main__':
    root=Tk()
    obj=info(root)
    root.mainloop()